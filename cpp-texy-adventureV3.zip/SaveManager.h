#pragma once

#include <string>
#include <vector>
#include "GameState.h"

// ==========================================
// Save Manager - File I/O for Game State
// ==========================================

class SaveManager {
public:
    // Save current game state to file
    // Returns true on success, false on failure
    static bool saveState(const GameState& state, const std::string& saveName);
    
    // Load state from file
    // Returns default GameState if file doesn't exist or is corrupted
    static GameState loadState(const std::string& filename);
    
    // List all available save files in working directory
    // Returns vector of save file names (without path)
    static std::vector<std::string> listSaves();
    
    // Delete a save file
    static bool deleteSave(const std::string& filename);
    
    // Check if a save file exists
    static bool saveExists(const std::string& filename);

private:
    // File extension for save files
    static constexpr const char* SAVE_EXTENSION = ".save";
    static constexpr const char* SAVE_PREFIX = "adv-world_";
    
    // Generate filename from save name
    static std::string generateFilename(const std::string& saveName);
    
    // Parse a save file
    static GameState parseFile(const std::string& path);
    
    // Write state to file
    static bool writeFile(const GameState& state, const std::string& path);
    
    // Get current timestamp string
    static std::string getCurrentTimestamp();
};
