#include "Menu.h"
#include "utils.h"
#include "ColorUtils.h"
#include "GameConstants.h"
#include "SaveManager.h"
#include <conio.h>
#include <iostream>
#include <windows.h>


void Menu::displayMenu(bool showLoadOption) {
    cls();
    printCentered("=== Main Menu ===", 5);
    printCentered("1. Start Game", 7);
    if (showLoadOption) {
        printCentered("2. Load Saved Game", 8);
        printCentered("8. Instructions", 9);
        printCentered("9. Exit", 10);
        // Color toggle display
        std::string colorStatus = g_colorsEnabled ? "Colors: ON  (press C to toggle)" : "Colors: OFF (press C to toggle)";
        printCentered(colorStatus, 12);
    } else {
        printCentered("8. Instructions", 8);
        printCentered("9. Exit", 9);
        // Color toggle display
        std::string colorStatus = g_colorsEnabled ? "Colors: ON  (press C to toggle)" : "Colors: OFF (press C to toggle)";
        printCentered(colorStatus, 11);
    }
    std::cout << std::endl;
}

Options Menu::getUserChoice(bool showLoadOption) {
    int promptLine = showLoadOption ? 14 : 13;
    printCentered("Please enter your choice: ", promptLine);
    char ch = _getch();
    
    // Handle color toggle separately
    char upperCh = (ch >= 'a' && ch <= 'z') ? (ch - 32) : ch;  // Convert to uppercase
    if (upperCh == Keys::COLOR_TOGGLE) {
        g_colorsEnabled = !g_colorsEnabled;
        return INVALID;  // Redisplay menu with updated status
    }
    int num = ch - '0';
    switch (num)
    {
    case START_GAME:
        return START_GAME;
        
    case LOAD_SAVED:
        if (showLoadOption)
            return LOAD_SAVED;
        // Fall through to invalid if not showing load option
        break;

    case EXIT_GAME:
        return EXIT_GAME;

    case PRESENT_INSTRUCTIONS:
        return PRESENT_INSTRUCTIONS;
    }
    
    // Invalid choice
    cls();
    printCentered("Invalid choice. Please try again.", 12);
    printCentered("Press any key...", 14);
    _getch();
    return INVALID;
}


void Menu::showInstructions() {
    cls();
    printCentered("========================= INSTRUCTIONS =========================", 1);

    printCentered("Goal: Guide both players to the final room to win.", 3);
    printCentered("Use keys, springs, and teamwork to overcome obstacles.", 4);

    printCentered("--------------------------------------------------------------", 6);
    printCentered("Player Controls", 7);

    printCentered("Player 1:  W=Up  X=Down  A=Left  D=Right  S=Stay  E=Drop", 9);
    printCentered("Player 2:  I=Up  M=Down  J=Left  L=Right  K=Stay  O=Drop", 10);

    printCentered("--------------------------------------------------------------", 12);
    printCentered("Game Elements", 13);

    printCentered("$ : Player 1    & : Player 2    W : Breakable Wall", 15);
    printCentered("# : Spring      K : Key         1-9 : Door", 16);
    printCentered("B : Auto Bomb   H : Hint        X : Indestructible Wall", 17);

    printCentered("--------------------------------------------------------------", 19);
    printCentered("Other Keys", 20);

    printCentered("ESC : Pause/Resume    H : Main Menu (Paused)", 21);
    printCentered("R   : Restart Level", 22);

    printCentered("Press any key to return to the main menu...", 24);

    _getch();

}

Options Menu::runOnce(bool showLoadOption)
{
    while (true)
    {
        displayMenu(showLoadOption);
        Options choice = getUserChoice(showLoadOption);
        if (choice == PRESENT_INSTRUCTIONS)
        {
            showInstructions();
            if (_kbhit())
            {
                continue; 
            }

        }
		else if (choice == START_GAME || choice == EXIT_GAME || (choice == LOAD_SAVED && showLoadOption))
            return choice;
    }
}

std::string Menu::showSaveSelection() {
    cls();
    
    std::vector<std::string> saves = SaveManager::listSaves();
    
    if (saves.empty()) {
        printCentered("No saved games found!", 8);
        printCentered("Press any key to return to menu...", 10);
        _getch();
        return "";
    }
    
    printCentered("=== Load Saved Game ===", 3);
    printCentered("Press number to load, ESC to cancel", 5);
    
    // Display up to 9 saves
    int maxSaves = (saves.size() > 9) ? 9 : static_cast<int>(saves.size());
    for (int i = 0; i < maxSaves; ++i) {
        gotoxy(10, 7 + i);
        std::cout << (i + 1) << ". " << saves[i];
    }
    
    // Wait for selection
    while (true) {
        char ch = _getch();
        
        if (ch == 27) {  // ESC
            return "";
        }
        
        int selection = ch - '0';
        if (selection >= 1 && selection <= maxSaves) {
            return saves[selection - 1];
        }
    }
}
