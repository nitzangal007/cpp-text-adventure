#pragma once

#include <iostream>
#include <string>

enum Options { START_GAME = 1, LOAD_SAVED = 2, PRESENT_INSTRUCTIONS = 8, EXIT_GAME = 9, INVALID };
class Menu
{
	public:
		void showInstructions();
		Options runOnce(bool showLoadOption = true);
		
		// Show save selection UI and return selected filename (empty if cancelled)
		std::string showSaveSelection();

	private:
		void displayMenu(bool showLoadOption);
		Options getUserChoice(bool showLoadOption);
};
