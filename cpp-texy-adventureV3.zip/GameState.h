#pragma once

#include <string>
#include <vector>
#include "Direction.h"

// ==========================================
// State Structures for Save/Load Game State
// ==========================================

// Player state snapshot
struct PlayerState {
    int x = 0;
    int y = 0;
    Direction direction = Direction::STAY;
    char heldItem = ' ';
    
    // Spring state
    int springMode = 0;  // 0=None, 1=Compressing, 2=Launching
    int springId = -1;
    int compressedCount = 0;
    Direction launchDir = Direction::STAY;
    int launchSpeed = 0;
    int ticksLeft = 0;
    int inheritedMomentum = 0;
};

// Bomb state snapshot
struct BombState {
    bool active = false;
    int x = 0;
    int y = 0;
    int countdown = 0;
};

// Auto-bomb state snapshot
struct AutoBombState {
    int x = 0;
    int y = 0;
    int countdown = 0;
};

// Tile modification (difference from original screen file)
struct TileChange {
    int screenIndex = 0;
    int x = 0;
    int y = 0;
    char newChar = ' ';
};

// Switch state snapshot
struct SwitchState {
    int x = 0;
    int y = 0;
    bool isOn = false;
};

// Room 3 Boss state snapshot (simplified)
struct BossStateData {
    int state = 0;  // BossState enum value
    int currentTaskIndex = 0;
    bool briefingShown = false;
    long long taskStartTime = 0;
    
    // 8-bit switches
    bool switches[8] = {false};
    
    // Snapshot data (for task restore)
    bool hasSnapshot = false;
    int player1SnapshotX = 0;
    int player1SnapshotY = 0;
    int player2SnapshotX = 0;
    int player2SnapshotY = 0;
};

// ==========================================
// Complete Game State
// ==========================================

struct GameState {
    // Metadata
    std::string saveName;
    std::string timestamp;
    
    // Screen info
    int currentScreenIndex = 0;
    std::vector<std::string> screenFileNames;
    
    // Players
    PlayerState player1;
    PlayerState player2;
    
    // Player start positions (for reset)
    int player1StartX = 0;
    int player1StartY = 0;
    int player2StartX = 0;
    int player2StartY = 0;
    
    // Game progress
    int lives = 6;
    int score = 0;
    size_t iteration = 0;
    long long gameTimeMs = 0;
    
    // Flags
    bool shownStory1 = false;
    bool shownStory2 = false;
    bool player1Ready = false;
    bool player2Ready = false;
    
    // M-trap state
    bool mTrapVisible = true;
    
    // Dynamic objects
    BombState bomb;
    std::vector<AutoBombState> autoBombs;
    
    // Tile modifications (diffs from original screen)
    std::vector<TileChange> tileChanges;
    
    // Switch states per screen
    std::vector<SwitchState> switchStates;
    
    // Boss state (if on screen 3)
    BossStateData bossState;
};
