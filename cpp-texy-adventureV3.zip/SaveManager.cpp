#include "SaveManager.h"
#include <fstream>
#include <filesystem>
#include <sstream>
#include <chrono>
#include <ctime>
#include <iomanip>

namespace fs = std::filesystem;

// ==========================================
// Public API
// ==========================================

bool SaveManager::saveState(const GameState& state, const std::string& saveName) {
    std::string filename = generateFilename(saveName);
    
    // Create state copy with metadata
    GameState stateCopy = state;
    stateCopy.saveName = saveName;
    stateCopy.timestamp = getCurrentTimestamp();
    
    return writeFile(stateCopy, filename);
}

GameState SaveManager::loadState(const std::string& filename) {
    return parseFile(filename);
}

std::vector<std::string> SaveManager::listSaves() {
    std::vector<std::string> saves;
    
    try {
        for (const auto& entry : fs::directory_iterator(fs::current_path())) {
            if (entry.is_regular_file()) {
                std::string name = entry.path().filename().string();
                // Check if file starts with save prefix and ends with extension
                if (name.find(SAVE_PREFIX) == 0 && 
                    name.size() > strlen(SAVE_EXTENSION) &&
                    name.substr(name.size() - strlen(SAVE_EXTENSION)) == SAVE_EXTENSION) {
                    saves.push_back(name);
                }
            }
        }
    }
    catch (...) {
        // Ignore filesystem errors
    }
    
    return saves;
}

bool SaveManager::deleteSave(const std::string& filename) {
    try {
        return fs::remove(filename);
    }
    catch (...) {
        return false;
    }
}

bool SaveManager::saveExists(const std::string& filename) {
    return fs::exists(filename);
}

// ==========================================
// Private Helpers
// ==========================================

std::string SaveManager::generateFilename(const std::string& saveName) {
    // Sanitize save name (remove special chars)
    std::string sanitized;
    for (char c : saveName) {
        if (isalnum(c) || c == '_' || c == '-') {
            sanitized += c;
        }
        else if (c == ' ') {
            sanitized += '_';
        }
    }
    
    if (sanitized.empty()) {
        sanitized = "quicksave";
    }
    
    return std::string(SAVE_PREFIX) + sanitized + SAVE_EXTENSION;
}

std::string SaveManager::getCurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    std::tm tm;
    localtime_s(&tm, &time);
    
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

bool SaveManager::writeFile(const GameState& state, const std::string& path) {
    std::ofstream file(path);
    if (!file.is_open()) {
        return false;
    }
    
    // Write header
    file << "[SAVE_STATE]\n";
    file << "name=" << state.saveName << "\n";
    file << "timestamp=" << state.timestamp << "\n";
    
    // Screen info
    file << "[SCREEN]\n";
    file << "current=" << state.currentScreenIndex << "\n";
    file << "files=" << state.screenFileNames.size() << "\n";
    for (const auto& name : state.screenFileNames) {
        file << "file=" << name << "\n";
    }
    
    // Game progress
    file << "[PROGRESS]\n";
    file << "lives=" << state.lives << "\n";
    file << "score=" << state.score << "\n";
    file << "iteration=" << state.iteration << "\n";
    file << "gameTimeMs=" << state.gameTimeMs << "\n";
    file << "shownStory1=" << (state.shownStory1 ? 1 : 0) << "\n";
    file << "shownStory2=" << (state.shownStory2 ? 1 : 0) << "\n";
    file << "player1Ready=" << (state.player1Ready ? 1 : 0) << "\n";
    file << "player2Ready=" << (state.player2Ready ? 1 : 0) << "\n";
    file << "mTrapVisible=" << (state.mTrapVisible ? 1 : 0) << "\n";
    
    // Player 1
    file << "[PLAYER1]\n";
    file << "x=" << state.player1.x << "\n";
    file << "y=" << state.player1.y << "\n";
    file << "dir=" << static_cast<int>(state.player1.direction) << "\n";
    file << "item=" << static_cast<int>(state.player1.heldItem) << "\n";
    file << "springMode=" << state.player1.springMode << "\n";
    file << "springId=" << state.player1.springId << "\n";
    file << "compressedCount=" << state.player1.compressedCount << "\n";
    file << "launchDir=" << static_cast<int>(state.player1.launchDir) << "\n";
    file << "launchSpeed=" << state.player1.launchSpeed << "\n";
    file << "ticksLeft=" << state.player1.ticksLeft << "\n";
    file << "inheritedMomentum=" << state.player1.inheritedMomentum << "\n";
    file << "startX=" << state.player1StartX << "\n";
    file << "startY=" << state.player1StartY << "\n";
    
    // Player 2
    file << "[PLAYER2]\n";
    file << "x=" << state.player2.x << "\n";
    file << "y=" << state.player2.y << "\n";
    file << "dir=" << static_cast<int>(state.player2.direction) << "\n";
    file << "item=" << static_cast<int>(state.player2.heldItem) << "\n";
    file << "springMode=" << state.player2.springMode << "\n";
    file << "springId=" << state.player2.springId << "\n";
    file << "compressedCount=" << state.player2.compressedCount << "\n";
    file << "launchDir=" << static_cast<int>(state.player2.launchDir) << "\n";
    file << "launchSpeed=" << state.player2.launchSpeed << "\n";
    file << "ticksLeft=" << state.player2.ticksLeft << "\n";
    file << "inheritedMomentum=" << state.player2.inheritedMomentum << "\n";
    file << "startX=" << state.player2StartX << "\n";
    file << "startY=" << state.player2StartY << "\n";
    
    // Bomb
    file << "[BOMB]\n";
    file << "active=" << (state.bomb.active ? 1 : 0) << "\n";
    if (state.bomb.active) {
        file << "x=" << state.bomb.x << "\n";
        file << "y=" << state.bomb.y << "\n";
        file << "countdown=" << state.bomb.countdown << "\n";
    }
    
    // Auto-bombs
    file << "[AUTOBOMBS]\n";
    file << "count=" << state.autoBombs.size() << "\n";
    for (const auto& ab : state.autoBombs) {
        file << "bomb=" << ab.x << "," << ab.y << "," << ab.countdown << "\n";
    }
    
    // Tile changes
    file << "[TILES]\n";
    file << "count=" << state.tileChanges.size() << "\n";
    for (const auto& tc : state.tileChanges) {
        file << "tile=" << tc.screenIndex << "," << tc.x << "," << tc.y 
             << "," << static_cast<int>(tc.newChar) << "\n";
    }
    
    // Switch states
    file << "[SWITCHES]\n";
    file << "count=" << state.switchStates.size() << "\n";
    for (const auto& sw : state.switchStates) {
        file << "switch=" << sw.x << "," << sw.y << "," << (sw.isOn ? 1 : 0) << "\n";
    }
    
    // Boss state
    file << "[BOSS]\n";
    file << "state=" << state.bossState.state << "\n";
    file << "taskIndex=" << state.bossState.currentTaskIndex << "\n";
    file << "briefingShown=" << (state.bossState.briefingShown ? 1 : 0) << "\n";
    file << "taskStartTime=" << state.bossState.taskStartTime << "\n";
    file << "switches=";
    for (int i = 0; i < 8; ++i) {
        file << (state.bossState.switches[i] ? 1 : 0);
    }
    file << "\n";
    file << "hasSnapshot=" << (state.bossState.hasSnapshot ? 1 : 0) << "\n";
    if (state.bossState.hasSnapshot) {
        file << "p1SnapX=" << state.bossState.player1SnapshotX << "\n";
        file << "p1SnapY=" << state.bossState.player1SnapshotY << "\n";
        file << "p2SnapX=" << state.bossState.player2SnapshotX << "\n";
        file << "p2SnapY=" << state.bossState.player2SnapshotY << "\n";
    }
    
    file << "[END]\n";
    file.close();
    return true;
}

GameState SaveManager::parseFile(const std::string& path) {
    GameState state;
    std::ifstream file(path);
    
    if (!file.is_open()) {
        return state;  // Return default state
    }
    
    std::string line;
    std::string currentSection;
    
    while (std::getline(file, line)) {
        // Skip empty lines
        if (line.empty()) continue;
        
        // Check for section headers
        if (line[0] == '[') {
            currentSection = line;
            continue;
        }
        
        // Parse key=value pairs
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        
        std::string key = line.substr(0, eq);
        std::string value = line.substr(eq + 1);
        
        // Handle based on section
        if (currentSection == "[SAVE_STATE]") {
            if (key == "name") state.saveName = value;
            else if (key == "timestamp") state.timestamp = value;
        }
        else if (currentSection == "[SCREEN]") {
            if (key == "current") state.currentScreenIndex = std::stoi(value);
            else if (key == "file") state.screenFileNames.push_back(value);
        }
        else if (currentSection == "[PROGRESS]") {
            if (key == "lives") state.lives = std::stoi(value);
            else if (key == "score") state.score = std::stoi(value);
            else if (key == "iteration") state.iteration = std::stoull(value);
            else if (key == "gameTimeMs") state.gameTimeMs = std::stoll(value);
            else if (key == "shownStory1") state.shownStory1 = (value == "1");
            else if (key == "shownStory2") state.shownStory2 = (value == "1");
            else if (key == "player1Ready") state.player1Ready = (value == "1");
            else if (key == "player2Ready") state.player2Ready = (value == "1");
            else if (key == "mTrapVisible") state.mTrapVisible = (value == "1");
        }
        else if (currentSection == "[PLAYER1]") {
            if (key == "x") state.player1.x = std::stoi(value);
            else if (key == "y") state.player1.y = std::stoi(value);
            else if (key == "dir") state.player1.direction = static_cast<Direction>(std::stoi(value));
            else if (key == "item") state.player1.heldItem = static_cast<char>(std::stoi(value));
            else if (key == "springMode") state.player1.springMode = std::stoi(value);
            else if (key == "springId") state.player1.springId = std::stoi(value);
            else if (key == "compressedCount") state.player1.compressedCount = std::stoi(value);
            else if (key == "launchDir") state.player1.launchDir = static_cast<Direction>(std::stoi(value));
            else if (key == "launchSpeed") state.player1.launchSpeed = std::stoi(value);
            else if (key == "ticksLeft") state.player1.ticksLeft = std::stoi(value);
            else if (key == "inheritedMomentum") state.player1.inheritedMomentum = std::stoi(value);
            else if (key == "startX") state.player1StartX = std::stoi(value);
            else if (key == "startY") state.player1StartY = std::stoi(value);
        }
        else if (currentSection == "[PLAYER2]") {
            if (key == "x") state.player2.x = std::stoi(value);
            else if (key == "y") state.player2.y = std::stoi(value);
            else if (key == "dir") state.player2.direction = static_cast<Direction>(std::stoi(value));
            else if (key == "item") state.player2.heldItem = static_cast<char>(std::stoi(value));
            else if (key == "springMode") state.player2.springMode = std::stoi(value);
            else if (key == "springId") state.player2.springId = std::stoi(value);
            else if (key == "compressedCount") state.player2.compressedCount = std::stoi(value);
            else if (key == "launchDir") state.player2.launchDir = static_cast<Direction>(std::stoi(value));
            else if (key == "launchSpeed") state.player2.launchSpeed = std::stoi(value);
            else if (key == "ticksLeft") state.player2.ticksLeft = std::stoi(value);
            else if (key == "inheritedMomentum") state.player2.inheritedMomentum = std::stoi(value);
            else if (key == "startX") state.player2StartX = std::stoi(value);
            else if (key == "startY") state.player2StartY = std::stoi(value);
        }
        else if (currentSection == "[BOMB]") {
            if (key == "active") state.bomb.active = (value == "1");
            else if (key == "x") state.bomb.x = std::stoi(value);
            else if (key == "y") state.bomb.y = std::stoi(value);
            else if (key == "countdown") state.bomb.countdown = std::stoi(value);
        }
        else if (currentSection == "[AUTOBOMBS]") {
            if (key == "bomb") {
                // Parse "x,y,countdown"
                std::istringstream iss(value);
                AutoBombState ab;
                char comma;
                iss >> ab.x >> comma >> ab.y >> comma >> ab.countdown;
                state.autoBombs.push_back(ab);
            }
        }
        else if (currentSection == "[TILES]") {
            if (key == "tile") {
                // Parse "screenIndex,x,y,charCode"
                std::istringstream iss(value);
                TileChange tc;
                int charCode;
                char comma;
                iss >> tc.screenIndex >> comma >> tc.x >> comma >> tc.y >> comma >> charCode;
                tc.newChar = static_cast<char>(charCode);
                state.tileChanges.push_back(tc);
            }
        }
        else if (currentSection == "[SWITCHES]") {
            if (key == "switch") {
                // Parse "x,y,isOn"
                std::istringstream iss(value);
                SwitchState sw;
                int isOn;
                char comma;
                iss >> sw.x >> comma >> sw.y >> comma >> isOn;
                sw.isOn = (isOn == 1);
                state.switchStates.push_back(sw);
            }
        }
        else if (currentSection == "[BOSS]") {
            if (key == "state") state.bossState.state = std::stoi(value);
            else if (key == "taskIndex") state.bossState.currentTaskIndex = std::stoi(value);
            else if (key == "briefingShown") state.bossState.briefingShown = (value == "1");
            else if (key == "taskStartTime") state.bossState.taskStartTime = std::stoll(value);
            else if (key == "switches") {
                for (int i = 0; i < 8 && i < static_cast<int>(value.size()); ++i) {
                    state.bossState.switches[i] = (value[i] == '1');
                }
            }
            else if (key == "hasSnapshot") state.bossState.hasSnapshot = (value == "1");
            else if (key == "p1SnapX") state.bossState.player1SnapshotX = std::stoi(value);
            else if (key == "p1SnapY") state.bossState.player1SnapshotY = std::stoi(value);
            else if (key == "p2SnapX") state.bossState.player2SnapshotX = std::stoi(value);
            else if (key == "p2SnapY") state.bossState.player2SnapshotY = std::stoi(value);
        }
    }
    
    file.close();
    return state;
}
